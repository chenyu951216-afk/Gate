"""FastAPI routers."""

